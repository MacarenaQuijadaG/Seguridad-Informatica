Enable-PSRemoting -Force

New-LocalGroup "RemotePowerShellUsers"
Add-LocalGroupMember -Group "RemotePowerShellUsers" -Member "empresa.local\empleado1"

Set-PSSessionConfiguration -Name Microsoft.PowerShell -ShowSecurityDescriptorUI